/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodbank;

public class User {
    
    
    private String name;
    private String bloodgroup;
    private String address;
    private String phone;
    private String referance;
    private String willing;
    private String gmail;
    private String user;
    private String password;
    
    
    public User(String Name,String BloodGroup,String Address,String Phone,String Referance, String Willing,String Gmail,String User, String Password)
    {
        this.name= Name;
        this.bloodgroup = BloodGroup;
        this.address= Address;
        this.phone = Phone;
        this.referance=Referance;
        this.willing= Willing;
        this.gmail = Gmail;
        this.user= User;
        this.password= Password;
    }

    User(String string, String string0, String string1, int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String getname()
    {
        return name;
    }
    
    public String getabloodgroup()
    {
        return bloodgroup;
    }
    
    public String getaddress()
    {
        return address;
    }
    
    public String getphone()
    {
        return phone;
    }
    
    public String getreferance()
    {
        return referance;
    }
    
    public String getwilling()
    {
        return willing;
    }
    public String getgmail(){
        return gmail;
    }
    public String getuser(){
        return user;
    }
    public String getpass()
    {
        return password;
    }
}

