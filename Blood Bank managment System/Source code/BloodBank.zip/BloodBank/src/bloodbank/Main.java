
package bloodbank;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lenovo
 */
public class Main extends javax.swing.JFrame {
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private Object Fname;
    private Statement stt = null;
    
    private String duser, dpass,dname;
    private String psw,usw;
   
    public Statement st = null;
    boolean b = false;
    private ImageIcon img;
    /**
     * Creates new form Main
     */
    public Main() {
        initComponents();
        img = new ImageIcon(getClass().getResource("error.jpg"));
        setIcon();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        passField = new javax.swing.JPasswordField();
        clearbtn = new javax.swing.JButton();
        loginbtn = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        clearbtn1 = new javax.swing.JButton();
        ckA = new javax.swing.JCheckBox();
        ckS = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Admin login");
        setBounds(new java.awt.Rectangle(550, 200, 0, 0));

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Harrington", 1, 44)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BloodBank Managment Admin");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel2.setText("User name: ");

        textField.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        textField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textFieldActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel4.setText("Password: ");

        passField.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        passField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passFieldActionPerformed(evt);
            }
        });

        clearbtn.setBackground(new java.awt.Color(102, 153, 0));
        clearbtn.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        clearbtn.setText("Clear");
        clearbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        clearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbtnActionPerformed(evt);
            }
        });

        loginbtn.setBackground(new java.awt.Color(0, 51, 255));
        loginbtn.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        loginbtn.setForeground(new java.awt.Color(255, 255, 255));
        loginbtn.setText("LogIn");
        loginbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        loginbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtnActionPerformed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bloodbank/blood.jpg"))); // NOI18N

        clearbtn1.setBackground(new java.awt.Color(51, 51, 255));
        clearbtn1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        clearbtn1.setForeground(new java.awt.Color(255, 255, 255));
        clearbtn1.setText("Home");
        clearbtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        clearbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbtn1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(ckA);
        ckA.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ckA.setText("Admin");

        buttonGroup1.add(ckS);
        ckS.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ckS.setText("Sub-Admin");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("Log in as");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Forgot password?????");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 153));
        jLabel8.setText("Click here...");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 824, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addGap(92, 92, 92)
                                .addComponent(clearbtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(clearbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(loginbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(95, 95, 95)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(ckA, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(ckS))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel4))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(passField)
                                            .addComponent(textField, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ckA, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ckS, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(passField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(loginbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(clearbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(clearbtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 823, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textFieldActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_textFieldActionPerformed

    private void passFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passFieldActionPerformed
        // TODO add your handling code here:  
    }//GEN-LAST:event_passFieldActionPerformed

    private void loginbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtnActionPerformed
        // TODO add your handling code here:
                String userName = textField.getText();
                String passa = passField.getText();
                
                try{
                if (ckA.isSelected()) {
                
                    Connection conn = null;
                    try{
                        
                        //Class.forName("com.mysql.jdbc.Driver");
                        conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/bloodtest","root","");
                        String us = "SELECT `User`, `Pass` FROM `login` WHERE 1";
                        java.sql.PreparedStatement pstt = conn.prepareStatement(us);
                        ResultSet rst = pstt.executeQuery();
                        if (rst.next()) {
                            String psw = rst.getString("Pass");
                            String usw = rst.getString("User");
                            if (usw.equals(userName)&&psw.equals(passa)) {
                                JOptionPane.showMessageDialog(null, "Succesfully Logged in");
                                BloodMain fra = new BloodMain();
                                fra.setVisible(true);
                                this.dispose();
                            }
                            else
                                JOptionPane.showMessageDialog(null,  "Invalid User Or Password\nTry again","",JOptionPane.PLAIN_MESSAGE,img);
                        }
                    }catch(Exception e){
                        
                    }
                    
            }
                
                else if (ckS.isSelected()) {
                    findAdmin();
                    try{
                       if (b==true) {
                       SubAdmin f = new SubAdmin(dname);
                       JOptionPane.showMessageDialog(this,"Succesfully logged in \n as sub-admin: "+dname);
                       f.setVisible(true);  
                       this.dispose();
                    }
                    else
                        JOptionPane.showMessageDialog(null, "Invalid User Or Password\nTry again","",JOptionPane.PLAIN_MESSAGE,img);
                    }catch(Exception e){
                    
                    }
                   
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    
    }//GEN-LAST:event_loginbtnActionPerformed
    
    
    public java.sql.Connection getConnection()
    {
        java.sql.Connection con = null;
        
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost/bloodtest","root","");
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
        return con;
        
    }
    
    public ArrayList<User2> ListUsers( String un,String psst){
        
        ArrayList<User2> usersList = new ArrayList<User2>();
        
        Statement stt;
        ResultSet rss;
        
        
        try{
            java.sql.Connection cont = getConnection();
            stt = cont.createStatement();
            String searchQuery = "SELECT * FROM `subadmin` WHERE `User` = '"+un+"' AND `Password` = '"+psst+"'  ORDER BY `Name`";
            rss = stt.executeQuery(searchQuery);
            
            User2 user;
            
            while(rss.next())
            {
                user = new User2(
                                 rss.getString("Name"),
                                 rss.getString("Referance"),
                                 rss.getString("Gmail"),
                                 rss.getString("User"),
                                 rss.getString("Password")
                                );
                usersList.add(user);
            }
            
            }catch(Exception ex){
                System.out.println(ex.getMessage());
            }
        
        
        return usersList;
    }
    
   
    public void findAdmin(){
        
        String psst = passField.getText();
        
        ArrayList<User2> users = ListUsers(textField.getText(),psst);
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"Name","Referance","Gmail","User","Password"});
        Object[] row = new Object[5];
        
        try{
            for(int i = 0; i < users.size(); i++){
            //String s = users.get(i).getname().toString();
            row[0] = users.get(i).getname();
            row[1] = users.get(i).getref();
            row[2] = users.get(i).getGmail();
            row[3] = users.get(i).getuser();
            row[4] = users.get(i).getpass();
            model.addRow(row);
        }
        
            dname = row[0].toString();
            duser = row[3].toString();
            dpass = row[4].toString();
        }
        catch(Exception e){ 
            
        }
        
        if (dname.equals("")||duser.equals("")||dpass.equals("")) {
            b = false;
        }
        else
            b = true;
    }    
 


    private void clearbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbtnActionPerformed
        // TODO add your handling code here:
        
        textField.setText("");
        passField.setText("");
        ckA.setSelected(false);
        ckS.setSelected(false);
    }//GEN-LAST:event_clearbtnActionPerformed

    private void clearbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbtn1ActionPerformed
        // TODO add your handling code here:
        
        HomeBlood home = new HomeBlood();
        home.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_clearbtn1ActionPerformed

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
        
        if (ckS.isSelected()) {
        AdminForgot_password frame = new AdminForgot_password();
        frame.setVisible(true);
        this.dispose();
        }
        else if (ckA.isSelected()) {
            getAdmin_info();
            
        try {
            sendMail("shourovhstu17@gmail.com");
        } catch (Exception ex) {
            Logger.getLogger(AdminForgot_password.class.getName()).log(Level.SEVERE, null, ex);
        }
        JOptionPane.showMessageDialog(null, "Email sent\n cheak it out");
        }
        else
            JOptionPane.showMessageDialog(null, "Select that you are admin or subadmin.","",JOptionPane.PLAIN_MESSAGE,img);

    }//GEN-LAST:event_jLabel8MouseClicked

    
    //Gmail portion
    public void sendMail(String recepient) throws Exception {
        System.out.println("Mail sending");
        Properties properties = new Properties();
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.host","smtp.gmail.com");
        properties.put("mail.smtp.port","587");
        
        final String myAccountEmail = "shourovcse17@gmail.com";
        final String password = "1112704646";
        
        Session session = Session.getInstance(properties, new Authenticator(){
            @Override
            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(myAccountEmail,password);
            }
        });
        Message message = prepareMessage(session,myAccountEmail, recepient);
        
        Transport.send(message);
        System.out.println("Meaaseg sent successfully...");
    }

    private  Message prepareMessage(Session session, String myAccountEmail,String recepient) {
        try{
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(myAccountEmail));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
        message.setSubject("Recover user id and password");
        String msss = "Your Forgotten info\nuser : "+usw+"\npass : "+psw;
        message.setText(""+msss);
        
        return message;
       }catch(Exception e){
           
       }
        return null;
        
    }
    
    //Gmail portion
    
    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox ckA;
    private javax.swing.JCheckBox ckS;
    private javax.swing.JButton clearbtn;
    private javax.swing.JButton clearbtn1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton loginbtn;
    private javax.swing.JPasswordField passField;
    private javax.swing.JTextField textField;
    // End of variables declaration//GEN-END:variables

    public void close(){
    
        WindowEvent winClosingEvent = new WindowEvent(this, WindowEvent.WINDOW_CLOSING); 
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
    }
    
    private void setIcon() {
        
              setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Miscellaneous-Icon.jpg")));
        }

    private void getAdmin_info() {

        Connection conn = null;
                    try{
                        
                        //Class.forName("com.mysql.jdbc.Driver");
                        conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/bloodtest","root","");
                        String us = "SELECT `User`, `Pass` FROM `login` WHERE 1";
                        java.sql.PreparedStatement pstt = conn.prepareStatement(us);
                        ResultSet rst = pstt.executeQuery();
                        if (rst.next()) {
                            psw = rst.getString("Pass");
                            usw = rst.getString("User");
                        }
                    }catch(Exception e){
                        
                    }
    }
}
