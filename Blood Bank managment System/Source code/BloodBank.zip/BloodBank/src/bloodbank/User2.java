
package bloodbank;

/**
 *
 * @author Lenovo
 */
public class User2 {
    private String name1s;
    private String referance1s;
    private String gmails;
    private String user1s;
    private String password1s;
    
    
    public User2(String Name,String Referance,String Gmail, String User, String Password)
    {
        this.name1s= Name;
        this.referance1s = Referance;
        this.gmails = Gmail;
        this.user1s= User;
        this.password1s = Password;
        
    }

    User2(String string, String string0, String string1, int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    public String getname()
    {
        return name1s;
    }
    
    public String getref()
    {
        return referance1s;
    }
    public String getGmail(){
        return gmails;
    }
    
    public String getuser()
    {
        return user1s;
    }
    
    public String getpass()
    {
        return password1s;
    }
    
   
}
